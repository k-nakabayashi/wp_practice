<?php
$dp_options = get_design_plus_option();
get_header();
?>
<main class="l-main">
<?php
get_template_part( 'template-parts/page-header' );
?>
</main>
<?php get_footer(); ?>
